﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double Numero1;
        double Numero2;
        double Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnsair_Click(object sender, EventArgs e)
        {

        }

        private void btnsair_Validated(object sender, EventArgs e)
        {
            Close();
        }
        private void btnsoma_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnmult_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            if (Numero2 == 0)
            {
                MessageBox.Show("Numero 2 não pode ser zero");
                txtNumero2.Focus();
            }
            else
            {
                Resultado = Numero1 / Numero2;
                txtResultado.Text = Resultado.ToString();
            }
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnsair)
            { return; }

            if (!Double.TryParse(txtNumero1.Text, out Numero1))
            {
                MessageBox.Show("Numero1 invalido!");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnsair)
            { return; }

            if (!Double.TryParse(txtNumero2.Text, out Numero2))
            {
                MessageBox.Show("Numero2 invalido!");
                txtNumero1.Focus();
            }
        }

        private void txtResultado_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnsair)
            { return; }

            if (!Double.TryParse(txtResultado.Text, out Resultado))
            {
                MessageBox.Show("Resultado invalido!");
                txtResultado.Focus();
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }
    }
}