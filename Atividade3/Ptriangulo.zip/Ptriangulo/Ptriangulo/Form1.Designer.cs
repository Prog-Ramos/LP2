﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblladoA = new System.Windows.Forms.Label();
            this.lblladoB = new System.Windows.Forms.Label();
            this.lblladoC = new System.Windows.Forms.Label();
            this.txtladoA = new System.Windows.Forms.TextBox();
            this.txtladoB = new System.Windows.Forms.TextBox();
            this.txtladoC = new System.Windows.Forms.TextBox();
            this.btnexecutar = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.errorProviderA = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderB = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderC = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderC)).BeginInit();
            this.SuspendLayout();
            // 
            // lblladoA
            // 
            this.lblladoA.AutoSize = true;
            this.lblladoA.Location = new System.Drawing.Point(81, 64);
            this.lblladoA.Name = "lblladoA";
            this.lblladoA.Size = new System.Drawing.Size(45, 16);
            this.lblladoA.TabIndex = 0;
            this.lblladoA.Text = "Lado1";
            // 
            // lblladoB
            // 
            this.lblladoB.AutoSize = true;
            this.lblladoB.Location = new System.Drawing.Point(81, 127);
            this.lblladoB.Name = "lblladoB";
            this.lblladoB.Size = new System.Drawing.Size(45, 16);
            this.lblladoB.TabIndex = 1;
            this.lblladoB.Text = "Lado2";
            // 
            // lblladoC
            // 
            this.lblladoC.AutoSize = true;
            this.lblladoC.Location = new System.Drawing.Point(81, 189);
            this.lblladoC.Name = "lblladoC";
            this.lblladoC.Size = new System.Drawing.Size(45, 16);
            this.lblladoC.TabIndex = 2;
            this.lblladoC.Text = "Lado3";
            // 
            // txtladoA
            // 
            this.txtladoA.Location = new System.Drawing.Point(163, 64);
            this.txtladoA.Name = "txtladoA";
            this.txtladoA.Size = new System.Drawing.Size(100, 22);
            this.txtladoA.TabIndex = 3;
            this.txtladoA.Validated += new System.EventHandler(this.txtladoA_Validated);
            // 
            // txtladoB
            // 
            this.txtladoB.Location = new System.Drawing.Point(163, 127);
            this.txtladoB.Name = "txtladoB";
            this.txtladoB.Size = new System.Drawing.Size(100, 22);
            this.txtladoB.TabIndex = 4;
            this.txtladoB.Validated += new System.EventHandler(this.txtladoB_Validated);
            // 
            // txtladoC
            // 
            this.txtladoC.Location = new System.Drawing.Point(163, 189);
            this.txtladoC.Name = "txtladoC";
            this.txtladoC.Size = new System.Drawing.Size(100, 22);
            this.txtladoC.TabIndex = 5;
            this.txtladoC.Validated += new System.EventHandler(this.txtladoC_Validated);
            // 
            // btnexecutar
            // 
            this.btnexecutar.Location = new System.Drawing.Point(84, 273);
            this.btnexecutar.Name = "btnexecutar";
            this.btnexecutar.Size = new System.Drawing.Size(79, 48);
            this.btnexecutar.TabIndex = 6;
            this.btnexecutar.Text = "Executar";
            this.btnexecutar.UseVisualStyleBackColor = true;
            this.btnexecutar.Click += new System.EventHandler(this.btnexecutar_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(184, 273);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(79, 48);
            this.btnlimpar.TabIndex = 7;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(290, 273);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(79, 48);
            this.btnsair.TabIndex = 8;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // errorProviderA
            // 
            this.errorProviderA.ContainerControl = this;
            // 
            // errorProviderB
            // 
            this.errorProviderB.ContainerControl = this;
            // 
            // errorProviderC
            // 
            this.errorProviderC.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1361, 497);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btnexecutar);
            this.Controls.Add(this.txtladoC);
            this.Controls.Add(this.txtladoB);
            this.Controls.Add(this.txtladoA);
            this.Controls.Add(this.lblladoC);
            this.Controls.Add(this.lblladoB);
            this.Controls.Add(this.lblladoA);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblladoA;
        private System.Windows.Forms.Label lblladoB;
        private System.Windows.Forms.Label lblladoC;
        private System.Windows.Forms.TextBox txtladoA;
        private System.Windows.Forms.TextBox txtladoB;
        private System.Windows.Forms.TextBox txtladoC;
        private System.Windows.Forms.Button btnexecutar;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnsair;
        private System.Windows.Forms.ErrorProvider errorProviderA;
        private System.Windows.Forms.ErrorProvider errorProviderB;
        private System.Windows.Forms.ErrorProvider errorProviderC;
    }
}

