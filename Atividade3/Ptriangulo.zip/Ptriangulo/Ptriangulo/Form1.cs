﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ladoA;
        double ladoB;  
        double ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtladoA.Clear();
            txtladoB.Clear();
            txtladoC.Clear();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            if ((ladoA < (ladoB + ladoC)) && (ladoA > (Math.Abs(ladoB - ladoC)) &&
               (ladoB < (ladoA + ladoC)) && (ladoB > (Math.Abs(ladoA - ladoC)) &&
               (ladoC < (ladoA + ladoB)) && (ladoC > (Math.Abs(ladoA - ladoB))))))
            {
                if (ladoA == ladoB && ladoB == ladoC)
                {
                    MessageBox.Show("Triângulo Equilátero");
                }

                else if (ladoA == ladoB || ladoB == ladoC || ladoA == ladoC)
                {
                    MessageBox.Show("Triângulo Isósceles");
                }

                else
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Não é um triângulo");
            }
        }
        
        private void txtladoA_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProviderA.SetError(txtladoA, "");

                ladoA = Convert.ToDouble(txtladoA.Text);
            }
            catch (Exception ex)
            {
                errorProviderA.SetError(txtladoA, "Valor A inválido!");
            }
        }

        private void txtladoB_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProviderB.SetError(txtladoB, "");

                ladoB = Convert.ToDouble(txtladoB.Text);
            }
            catch (Exception ex)
            {
                errorProviderB.SetError(txtladoB, "Valor B inválido!");
            }
        }

        private void txtladoC_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProviderC.SetError(txtladoC, "");

                ladoC = Convert.ToDouble(txtladoC.Text);
            }
            catch (Exception ex)
            {
                errorProviderC.SetError(txtladoC, "Valor C inválido!");
            }
        }
    }
}