﻿namespace Atividade6
{
    partial class frm_Exc2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Executar = new System.Windows.Forms.Button();
            this.lstbx_Valores = new System.Windows.Forms.ListBox();
            this.btnsair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Executar
            // 
            this.btn_Executar.Font = new System.Drawing.Font("Microsoft YaHei", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Executar.Location = new System.Drawing.Point(464, 395);
            this.btn_Executar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Executar.Name = "btn_Executar";
            this.btn_Executar.Size = new System.Drawing.Size(168, 96);
            this.btn_Executar.TabIndex = 0;
            this.btn_Executar.Text = "Executar";
            this.btn_Executar.UseVisualStyleBackColor = true;
            this.btn_Executar.Click += new System.EventHandler(this.btn_Executar_Click);
            // 
            // lstbx_Valores
            // 
            this.lstbx_Valores.FormattingEnabled = true;
            this.lstbx_Valores.ItemHeight = 16;
            this.lstbx_Valores.Location = new System.Drawing.Point(321, 50);
            this.lstbx_Valores.Margin = new System.Windows.Forms.Padding(4);
            this.lstbx_Valores.Name = "lstbx_Valores";
            this.lstbx_Valores.Size = new System.Drawing.Size(482, 260);
            this.lstbx_Valores.TabIndex = 1;
            // 
            // btnsair
            // 
            this.btnsair.Font = new System.Drawing.Font("Microsoft YaHei", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsair.Location = new System.Drawing.Point(908, 466);
            this.btnsair.Margin = new System.Windows.Forms.Padding(4);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(106, 75);
            this.btnsair.TabIndex = 2;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // frm_Exc2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.lstbx_Valores);
            this.Controls.Add(this.btn_Executar);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_Exc2";
            this.Text = "frm_Exc2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Executar;
        private System.Windows.Forms.ListBox lstbx_Valores;
        private System.Windows.Forms.Button btnsair;
    }
}