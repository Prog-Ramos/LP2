﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btncontanum = new System.Windows.Forms.Button();
            this.btncaracterbranco = new System.Windows.Forms.Button();
            this.btncontaletras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(128, 37);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(403, 121);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btncontanum
            // 
            this.btncontanum.Location = new System.Drawing.Point(128, 217);
            this.btncontanum.Name = "btncontanum";
            this.btncontanum.Size = new System.Drawing.Size(107, 72);
            this.btncontanum.TabIndex = 1;
            this.btncontanum.Text = "Conta números";
            this.btncontanum.UseVisualStyleBackColor = true;
            this.btncontanum.Click += new System.EventHandler(this.btncontanum_Click);
            // 
            // btncaracterbranco
            // 
            this.btncaracterbranco.Location = new System.Drawing.Point(275, 217);
            this.btncaracterbranco.Name = "btncaracterbranco";
            this.btncaracterbranco.Size = new System.Drawing.Size(107, 72);
            this.btncaracterbranco.TabIndex = 2;
            this.btncaracterbranco.Text = "Localiza 1° caracter em branco";
            this.btncaracterbranco.UseVisualStyleBackColor = true;
            this.btncaracterbranco.Click += new System.EventHandler(this.btncaracterbranco_Click);
            // 
            // btncontaletras
            // 
            this.btncontaletras.Location = new System.Drawing.Point(424, 217);
            this.btncontaletras.Name = "btncontaletras";
            this.btncontaletras.Size = new System.Drawing.Size(107, 72);
            this.btncontaletras.TabIndex = 3;
            this.btncontaletras.Text = "Conta letras";
            this.btncontaletras.UseVisualStyleBackColor = true;
            this.btncontaletras.Click += new System.EventHandler(this.btncontaletras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 534);
            this.Controls.Add(this.btncontaletras);
            this.Controls.Add(this.btncaracterbranco);
            this.Controls.Add(this.btncontanum);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btncontanum;
        private System.Windows.Forms.Button btncaracterbranco;
        private System.Windows.Forms.Button btncontaletras;
    }
}