﻿namespace PTesteMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.btnremover = new System.Windows.Forms.Button();
            this.btninverter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(177, 143);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(100, 22);
            this.txtpalavra2.TabIndex = 7;
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(177, 90);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(100, 22);
            this.txtpalavra1.TabIndex = 6;
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(96, 143);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(61, 16);
            this.lblpalavra2.TabIndex = 5;
            this.lblpalavra2.Text = "Palavra2";
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(96, 90);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(61, 16);
            this.lblpalavra1.TabIndex = 4;
            this.lblpalavra1.Text = "Palavra1";
            // 
            // btnremover
            // 
            this.btnremover.Location = new System.Drawing.Point(99, 232);
            this.btnremover.Name = "btnremover";
            this.btnremover.Size = new System.Drawing.Size(115, 66);
            this.btnremover.TabIndex = 8;
            this.btnremover.Text = "Remover ocorrências 1° no 2°";
            this.btnremover.UseVisualStyleBackColor = true;
            this.btnremover.Click += new System.EventHandler(this.btnremover_Click);
            // 
            // btninverter
            // 
            this.btninverter.Location = new System.Drawing.Point(275, 232);
            this.btninverter.Name = "btninverter";
            this.btninverter.Size = new System.Drawing.Size(115, 66);
            this.btninverter.TabIndex = 9;
            this.btninverter.Text = "Inverter 1°";
            this.btninverter.UseVisualStyleBackColor = true;
            this.btninverter.Click += new System.EventHandler(this.btninverter_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btninverter);
            this.Controls.Add(this.btnremover);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Name = "frmExercicio3";
            this.Text = "Inverter 1°";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Button btnremover;
        private System.Windows.Forms.Button btninverter;
    }
}