﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace pcalculo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] Consumo = new double[5, 4];
            string aux = "";
            string[] nomesSetores = { "produção", "escritorio", "refeitorio", "limpeza", "logistica" };
            double[] totalSetor = new double[5];

            for (int setor = 0; setor < 5; setor++)
            {
                for (int semana = 0; semana < 4; semana++)
                {
                    aux = Interaction.InputBox("Digite o consumo do setor " + nomesSetores[setor] + " na semana " + (semana + 1) + ":");

                    if (aux == "")
                        return;
                    if (!double.TryParse(aux, out Consumo[setor, semana]) || Consumo[setor, semana] < 0)
                    {
                        MessageBox.Show("Valor invalido");
                        semana--;
                    }
                    else
                    {
                        totalSetor[setor] += Consumo[setor, semana];
                    }
                }
            }
            double totalGeral = 0;
            for (int setor = 0; setor < 5; setor++)
            {
                lstbxresultado.Items.Add($"{nomesSetores[setor]}: {totalSetor[setor]}L -> {totalSetor[setor] * 0.01:C2}");
                totalGeral += totalSetor[setor];
            }
            lstbxresultado.Items.Add("------------------------------");
            lstbxresultado.Items.Add($"total geral : {totalGeral}L ->  {totalGeral * 0.01:C2}");
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            lstbxresultado.Items.Clear();
        }
    }
}
