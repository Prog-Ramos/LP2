﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalcIMC
{
    public partial class Form1 : Form
    {
        double altura;
        double peso;
        double imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            mskbxaltura.Clear();
            mskbxpeso.Clear();
            txtimc.Clear();
        }

        private void mskbxaltura_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(mskbxaltura.Text, out altura) || altura<=0)
            {
                MessageBox.Show("Altura Inválida!");
                mskbxaltura.Focus();
            }
        }

        private void mskbxpeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxpeso.Text, out peso) || peso<=0)
            {
                MessageBox.Show("Peso Inválido!");
                mskbxpeso.Focus();
            }
        }

        private void txtimc_Validated(object sender, EventArgs e)
        {
            
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            imc = (peso / (altura * altura));
            imc = Math.Round(imc,1);
            txtimc.Text = imc.ToString();

            if (imc<18.5)
            {
                MessageBox.Show("Magreza");
            }
            else if(imc<=24.9)
            {
                MessageBox.Show("Normal");
            }
            else if (imc <= 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }
            else if (imc <= 39.9)
            {
                MessageBox.Show("Obesidade");
            }
            else
            {
                MessageBox.Show("Obesidade Grave");
            }

           
        }
    }
}
