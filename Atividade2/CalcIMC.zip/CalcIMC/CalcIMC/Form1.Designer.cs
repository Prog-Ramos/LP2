﻿namespace CalcIMC
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblaltura = new System.Windows.Forms.Label();
            this.lblpeso = new System.Windows.Forms.Label();
            this.lblimc = new System.Windows.Forms.Label();
            this.mskbxaltura = new System.Windows.Forms.MaskedTextBox();
            this.mskbxpeso = new System.Windows.Forms.MaskedTextBox();
            this.txtimc = new System.Windows.Forms.TextBox();
            this.btncalcular = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblaltura
            // 
            this.lblaltura.AutoSize = true;
            this.lblaltura.Location = new System.Drawing.Point(177, 77);
            this.lblaltura.Name = "lblaltura";
            this.lblaltura.Size = new System.Drawing.Size(41, 16);
            this.lblaltura.TabIndex = 0;
            this.lblaltura.Text = "Altura";
            // 
            // lblpeso
            // 
            this.lblpeso.AutoSize = true;
            this.lblpeso.Location = new System.Drawing.Point(177, 127);
            this.lblpeso.Name = "lblpeso";
            this.lblpeso.Size = new System.Drawing.Size(39, 16);
            this.lblpeso.TabIndex = 1;
            this.lblpeso.Text = "Peso";
            // 
            // lblimc
            // 
            this.lblimc.AutoSize = true;
            this.lblimc.Location = new System.Drawing.Point(177, 184);
            this.lblimc.Name = "lblimc";
            this.lblimc.Size = new System.Drawing.Size(30, 16);
            this.lblimc.TabIndex = 2;
            this.lblimc.Text = "IMC";
            // 
            // mskbxaltura
            // 
            this.mskbxaltura.Location = new System.Drawing.Point(277, 77);
            this.mskbxaltura.Mask = "0.00";
            this.mskbxaltura.Name = "mskbxaltura";
            this.mskbxaltura.Size = new System.Drawing.Size(100, 22);
            this.mskbxaltura.TabIndex = 3;
            this.mskbxaltura.Validated += new System.EventHandler(this.mskbxaltura_Validated);
            // 
            // mskbxpeso
            // 
            this.mskbxpeso.Location = new System.Drawing.Point(277, 127);
            this.mskbxpeso.Mask = "900.00";
            this.mskbxpeso.Name = "mskbxpeso";
            this.mskbxpeso.Size = new System.Drawing.Size(100, 22);
            this.mskbxpeso.TabIndex = 4;
            this.mskbxpeso.Validated += new System.EventHandler(this.mskbxpeso_Validated);
            // 
            // txtimc
            // 
            this.txtimc.Enabled = false;
            this.txtimc.Location = new System.Drawing.Point(277, 184);
            this.txtimc.Name = "txtimc";
            this.txtimc.Size = new System.Drawing.Size(100, 22);
            this.txtimc.TabIndex = 5;
            this.txtimc.Validated += new System.EventHandler(this.txtimc_Validated);
            // 
            // btncalcular
            // 
            this.btncalcular.Location = new System.Drawing.Point(180, 245);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(99, 49);
            this.btncalcular.TabIndex = 6;
            this.btncalcular.Text = "Calcular";
            this.btncalcular.UseVisualStyleBackColor = true;
            this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(308, 245);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(99, 49);
            this.btnlimpar.TabIndex = 7;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(435, 245);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(99, 49);
            this.btnsair.TabIndex = 8;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 492);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.txtimc);
            this.Controls.Add(this.mskbxpeso);
            this.Controls.Add(this.mskbxaltura);
            this.Controls.Add(this.lblimc);
            this.Controls.Add(this.lblpeso);
            this.Controls.Add(this.lblaltura);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblaltura;
        private System.Windows.Forms.Label lblpeso;
        private System.Windows.Forms.Label lblimc;
        private System.Windows.Forms.MaskedTextBox mskbxaltura;
        private System.Windows.Forms.MaskedTextBox mskbxpeso;
        private System.Windows.Forms.TextBox txtimc;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnsair;
    }
}

