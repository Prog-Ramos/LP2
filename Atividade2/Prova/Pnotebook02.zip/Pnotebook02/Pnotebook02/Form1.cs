﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pnotebook02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            lstbxresultado.Items.Clear();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            double[,] valnotebook = new double[2, 3];
            string aux = "";
            string[] nomesNotebooks = { "notebook 1", "notebook 2" };
            double[] totalvalores = new double[2];


            for (int notebook = 0; notebook < 2; notebook++)
            {
                for (int loja = 0; loja < 3; loja++)
                {
                    aux = Interaction.InputBox("Digite o valor do " + nomesNotebooks[notebook] + " na loja " + (loja + 1) + ":");

                    if (aux == "")
                        return;

                    if (!double.TryParse(aux, out valnotebook[notebook, loja]) || valnotebook[notebook, loja] < 0)
                    {
                        MessageBox.Show("Valor invalido");
                        loja--;
                    }
                    else
                    {
                        totalvalores[notebook] += valnotebook[notebook, loja];
                    }
                    lstbxresultado.Items.Add($"Valor do {nomesNotebooks[notebook]} na loja{loja + 1} {valnotebook[notebook, loja] * 1:C2}");


                }
                lstbxresultado.Items.Add($"A Média dos valores do notebook é de: {totalvalores[notebook] / 3:C2}");
                lstbxresultado.Items.Add($"-------------------------");
            }
        }
    }
}